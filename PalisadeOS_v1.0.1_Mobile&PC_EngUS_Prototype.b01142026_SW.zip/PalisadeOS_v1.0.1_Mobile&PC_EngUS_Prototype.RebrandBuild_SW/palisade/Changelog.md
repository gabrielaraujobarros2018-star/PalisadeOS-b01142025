# Palisade

## Palisade 1.0.1 - Rebranding

NeoProto -> Palisade

Plus, added slogan:

> Palisade OS — a traditional operating system built around strict boundaries and layered control.
