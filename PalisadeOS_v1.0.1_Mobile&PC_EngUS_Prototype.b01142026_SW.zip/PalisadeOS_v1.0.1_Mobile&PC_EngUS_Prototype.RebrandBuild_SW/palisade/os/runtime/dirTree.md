/palisade/runtime
├── loader
│   ├── svc_loader.c
│   ├── bridge_loader.c
│   ├── profile_loader.c
│   └── manifest_loader.c
│
├── ipc
│   ├── channel.map
│   ├── signal.router.c
│   └── sharedmem.c
│
├── lifecycle
│   ├── phase_manager.c
│   ├── state_sync.c
│   └── transition.log
│
├── syscall
│   ├── syscall.map
│   ├── syscall_gate.c
│   └── userspace_wrap.c
│
├── services
│   ├── service_registry.c
│   ├── service_state.db
│   └── watchdog.c
│
├── execution
│   ├── exec_policy.cfg
│   ├── elf_resolver.c
│   └── permission_gate.c
│
├── gui
│   ├── compositor_link.c
│   ├── input_bridge.c
│   └── render_sync.c
│
├── shell
│   ├── shell_bridge.c
│   ├── command_dispatch.c
│   └── env_sync.c
│
├── recovery
│   ├── fault_handler.c
│   ├── rollback_engine.c
│   └── safe_mode.flag
│
└── init
    ├── runtime_init.c
    ├── runtime_order.cfg
    └── runtime.ready