#pragma once

struct Sunlight {
    float angle;
    float intensity;
    float warmth;
};

inline Sunlight systemSun() {
    return {45.0f, 0.85f, 0.6f};
}