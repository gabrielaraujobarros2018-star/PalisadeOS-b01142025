#pragma once

struct Shadow {
    float offsetX;
    float offsetY;
    float blur;
    float opacity;
};

inline Shadow elevation(int level) {
    return {0, level * 2.0f, level * 6.0f, 0.25f};
}