#pragma once

#include <cmath>
#include <vector>
#include <algorithm>

struct Color {
    float r;
    float g;
    float b;
    float a;

    Color() : r(0), g(0), b(0), a(1) {}
    Color(float R, float G, float B, float A = 1.0f)
        : r(R), g(G), b(B), a(A) {}

    Color operator+(const Color& o) const {
        return {r + o.r, g + o.g, b + o.b, a};
    }

    Color operator*(float f) const {
        return {r * f, g * f, b * f, a};
    }

    static Color lerp(const Color& a, const Color& b, float t) {
        return {
            a.r + (b.r - a.r) * t,
            a.g + (b.g - a.g) * t,
            a.b + (b.b - a.b) * t,
            a.a + (b.a - a.a) * t
        };
    }
};

struct Vec3 {
    float x;
    float y;
    float z;

    Vec3() : x(0), y(0), z(0) {}
    Vec3(float X, float Y, float Z) : x(X), y(Y), z(Z) {}

    Vec3 normalized() const {
        float l = std::sqrt(x*x + y*y + z*z);
        if (l == 0) return {};
        return {x/l, y/l, z/l};
    }

    static float dot(const Vec3& a, const Vec3& b) {
        return a.x*b.x + a.y*b.y + a.z*b.z;
    }
};

struct ButtonSurface {
    float elevation;
    float roughness;
    float occlusion;
};

struct ScreenPoint {
    float x;
    float y;
};

class SunlightShader {
    float sunAzimuth;
    float sunElevation;
    float intensity;
    float temperature;

    Vec3 sunDirection;
    Color sunColor;

public:
    SunlightShader()
        : sunAzimuth(0),
          sunElevation(45),
          intensity(1.0f),
          temperature(5500.0f) {
        updateDirection();
        updateColor();
    }

    void setSunAngles(float azimuthDeg, float elevationDeg) {
        sunAzimuth = azimuthDeg;
        sunElevation = std::clamp(elevationDeg, 1.0f, 89.0f);
        updateDirection();
    }

    void setIntensity(float i) {
        intensity = std::clamp(i, 0.0f, 2.0f);
    }

    void setTemperature(float kelvin) {
        temperature = std::clamp(kelvin, 2000.0f, 9000.0f);
        updateColor();
    }

    Color applyToButton(
        const Color& base,
        const ButtonSurface& surface,
        const ScreenPoint& pos
    ) const {
        float ndotl = std::max(0.0f, Vec3::dot(
            surfaceNormal(surface.elevation),
            sunDirection
        ));

        float specular = computeSpecular(surface, ndotl);
        float diffuse = ndotl * (1.0f - surface.roughness);

        float overlayStrength =
            intensity *
            (1.0f - surface.occlusion) *
            verticalFalloff(pos.y);

        Color light = sunColor * overlayStrength;

        Color litDiffuse = blendSoftLight(base, light * diffuse);
        Color litSpecular = blendAdditive(litDiffuse, light * specular);

        return clampColor(litSpecular);
    }

private:
    void updateDirection() {
        float az = sunAzimuth * 3.1415926f / 180.0f;
        float el = sunElevation * 3.1415926f / 180.0f;

        sunDirection = {
            std::cos(el) * std::cos(az),
            std::sin(el),
            std::cos(el) * std::sin(az)
        };
        sunDirection = sunDirection.normalized();
    }

    void updateColor() {
        sunColor = kelvinToRGB(temperature);
    }

    Vec3 surfaceNormal(float elevation) const {
        float tilt = std::clamp(elevation * 0.05f, 0.0f, 0.25f);
        return Vec3(0, 1.0f - tilt, tilt).normalized();
    }

    float computeSpecular(
        const ButtonSurface& surface,
        float ndotl
    ) const {
        float gloss = 1.0f - surface.roughness;
        float spec = std::pow(ndotl, 8.0f + gloss * 32.0f);
        return spec * 0.5f;
    }

    float verticalFalloff(float y) const {
        float t = 1.0f - std::clamp(y, 0.0f, 1.0f);
        return 0.4f + t * 0.6f;
    }

    Color blendAdditive(const Color& base, const Color& light) const {
        return {
            base.r + light.r,
            base.g + light.g,
            base.b + light.b,
            base.a
        };
    }

    Color blendSoftLight(const Color& base, const Color& light) const {
        auto soft = [](float b, float l) {
            if (l < 0.5f)
                return b - (1.0f - 2.0f * l) * b * (1.0f - b);
            return b + (2.0f * l - 1.0f) *
                   (std::sqrt(b) - b);
        };

        return {
            soft(base.r, light.r),
            soft(base.g, light.g),
            soft(base.b, light.b),
            base.a
        };
    }

    Color clampColor(const Color& c) const {
        return {
            std::clamp(c.r, 0.0f, 1.0f),
            std::clamp(c.g, 0.0f, 1.0f),
            std::clamp(c.b, 0.0f, 1.0f),
            c.a
        };
    }

    Color kelvinToRGB(float kelvin) const {
        float t = kelvin / 100.0f;
        float r, g, b;

        if (t <= 66) {
            r = 1.0f;
            g = std::clamp(0.390081f * std::log(t) - 0.631841f, 0.0f, 1.0f);
        } else {
            r = std::clamp(1.292936f * std::pow(t - 60, -0.133204f), 0.0f, 1.0f);
            g = std::clamp(1.129891f * std::pow(t - 60, -0.075515f), 0.0f, 1.0f);
        }

        if (t >= 66) {
            b = 1.0f;
        } else if (t <= 19) {
            b = 0.0f;
        } else {
            b = std::clamp(
                0.543207f * std::log(t - 10) - 1.196254f,
                0.0f,
                1.0f
            );
        }

        return {r, g, b, 1.0f};
    }
};