// PhoneLayout.cpp
LayoutMetrics PhoneLayout::metrics(const DeviceProfile&) {
    return {4, 72, true};
}