// DesktopLayout.cpp
LayoutMetrics DesktopLayout::metrics(const DeviceProfile&) {
    return {12, 56, false};
}