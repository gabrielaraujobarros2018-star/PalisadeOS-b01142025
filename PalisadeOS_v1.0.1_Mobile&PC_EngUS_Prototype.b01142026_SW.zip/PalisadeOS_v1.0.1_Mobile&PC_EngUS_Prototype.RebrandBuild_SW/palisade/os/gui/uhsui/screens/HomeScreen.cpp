#include "Screen.h"
#include "Renderer.h"
#include "Context.h"

class HomeScreen : public Screen {
public:
    std::string id() const override { return "home"; }

    void render(Renderer& r, Context& ctx) override {
        r.surface();
        r.grid();
        r.dock();
        r.applySunlight();
    }
};