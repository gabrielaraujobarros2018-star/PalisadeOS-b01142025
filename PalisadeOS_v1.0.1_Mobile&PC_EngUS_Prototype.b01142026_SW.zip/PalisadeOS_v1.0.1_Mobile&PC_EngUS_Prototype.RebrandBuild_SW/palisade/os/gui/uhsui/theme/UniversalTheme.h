#pragma once
#include <cstdint>

struct Color {
    float r, g, b, a;
};

struct UniversalTheme {
    Color surface;
    Color accent;
    Color text;
    float cornerRadius;
    float elevationUnit;
};