/
├── boot/
│   ├── bootloader/
│   │   ├── bios/
│   │   │   ├── stage1.bin
│   │   │   └── stage2.bin
│   │   ├── uefi/
│   │   │   ├── BOOTX64.EFI
│   │   │   └── BOOTAA64.EFI
│   │   └── config/
│   │       └── boot.cfg
│   ├── kernel/
│   │   ├── kernel.bin
│   │   └── kernel.sym
│   └── initramfs.img
│
├── kernel/
│   ├── arch/
│   │   ├── x86/
│   │   │   ├── boot/
│   │   │   ├── mmu/
│   │   │   ├── interrupts/
│   │   │   └── cpu/
│   │   ├── x86_64/
│   │   ├── arm/
│   │   └── arm64/
│   │
│   ├── core/
│   │   ├── init/
│   │   ├── scheduler/
│   │   ├── syscall/
│   │   ├── ipc/
│   │   └── panic/
│   │
│   ├── mm/
│   │   ├── paging/
│   │   ├── vm/
│   │   ├── kmalloc/
│   │   └── slab/
│   │
│   ├── drivers/
│   │   ├── block/
│   │   │   ├── ata/
│   │   │   ├── sata/
│   │   │   └── nvme/
│   │   ├── char/
│   │   │   ├── tty/
│   │   │   ├── keyboard/
│   │   │   └── mouse/
│   │   ├── net/
│   │   │   ├── ethernet/
│   │   │   ├── wifi/
│   │   │   └── loopback/
│   │   ├── video/
│   │   │   ├── vga/
│   │   │   ├── framebuffer/
│   │   │   └── gpu/
│   │   └── bus/
│   │       ├── pci/
│   │       ├── pcie/
│   │       └── usb/
│   │
│   ├── fs/
│   │   ├── vfs/
│   │   ├── fat/
│   │   ├── ext2/
│   │   ├── ext4/
│   │   ├── procfs/
│   │   └── devfs/
│   │
│   ├── net/
│   │   ├── socket/
│   │   ├── arp/
│   │   ├── ip/
│   │   ├── tcp/
│   │   └── udp/
│   │
│   ├── security/
│   │   ├── permissions/
│   │   ├── capabilities/
│   │   ├── selinux/
│   │   └── sandbox/
│   │
│   ├── lib/
│   │   ├── string/
│   │   ├── math/
│   │   └── atomic/
│   │
│   └── include/
│       ├── kernel/
│       ├── arch/
│       ├── drivers/
│       └── uapi/
│
├── sbin/
│   ├── init
│   ├── mount
│   ├── umount
│   ├── shutdown
│   ├── reboot
│   └── fsck
│
├── bin/
│   ├── sh
│   ├── ls
│   ├── cp
│   ├── mv
│   ├── rm
│   ├── cat
│   ├── echo
│   └── ps
│
├── lib/
│   ├── libc.so
│   ├── libm.so
│   ├── ld.so
│   └── modules/
│       ├── fs/
│       ├── net/
│       └── drivers/
│
├── etc/
│   ├── passwd
│   ├── group
│   ├── fstab
│   ├── hostname
│   ├── init.d/
│   │   ├── rcS
│   │   └── rc.local
│   └── network/
│       └── interfaces
│
├── dev/
│   ├── null
│   ├── zero
│   ├── tty
│   ├── tty0
│   ├── sda
│   ├── sda1
│   ├── random
│   └── urandom
│
├── proc/
│   ├── cpuinfo
│   ├── meminfo
│   ├── uptime
│   ├── mounts
│   └── sys/
│       ├── kernel/
│       ├── vm/
│       └── fs/
│
├── sys/
│   ├── devices/
│   ├── bus/
│   ├── class/
│   └── firmware/
│
├── usr/
│   ├── bin/
│   ├── sbin/
│   ├── lib/
│   ├── include/
│   └── share/
│       ├── man/
│       ├── terminfo/
│       └── locale/
│
├── var/
│   ├── log/
│   │   ├── kernel.log
│   │   └── boot.log
│   ├── run/
│   ├── tmp/
│   └── cache/
│
├── home/
│   └── user/
│       ├── .config/
│       ├── .local/
│       ├── bin/
│       └── projects/
│
└── tmp/