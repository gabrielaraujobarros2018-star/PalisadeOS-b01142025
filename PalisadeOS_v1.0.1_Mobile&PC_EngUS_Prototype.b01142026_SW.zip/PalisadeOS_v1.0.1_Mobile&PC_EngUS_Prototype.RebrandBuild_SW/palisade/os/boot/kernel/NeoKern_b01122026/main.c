#include <stdint.h>

volatile uint32_t* fb = (uint32_t*)0xE0000000;
uint32_t width = 1024, height = 768;

static inline void outb(uint16_t p, uint8_t v) {
    __asm__ volatile ("outb %0,%1"::"a"(v),"Nd"(p));
}

void draw_rect(int x,int y,int w,int h,uint32_t c){
    for(int j=0;j<h;j++)
        for(int i=0;i<w;i++)
            fb[(y+j)*width+(x+i)] = c;
}

void kernel_main(void){
    draw_rect(0,0,width,height,0x00202020);
    draw_rect(100,100,400,200,0x004040FF);

    outb(0x60,0xF4); // enable keyboard

    while(1){
        __asm__("hlt");
    }
}