/hw              → what exists physically
/firmware        → how hardware wakes up
/src             → what gets built
/kernel          → what runs in ring 0
/inner-workings  → why everything behaves the way it does