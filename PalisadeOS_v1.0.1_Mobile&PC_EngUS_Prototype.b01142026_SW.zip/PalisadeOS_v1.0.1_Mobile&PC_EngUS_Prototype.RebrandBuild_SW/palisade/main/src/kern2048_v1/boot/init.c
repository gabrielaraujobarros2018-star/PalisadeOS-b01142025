// kernel/boot/init.c
#include "system.h"
#include "hw.h"

void early_init() {
    log_event("BOOT", "Early init");
    display_print("PalisadeOS starting");
}