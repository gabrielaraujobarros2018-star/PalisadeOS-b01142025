// kernel/boot/boot.c
#include "system.h"

extern void kernel_main();

void boot_start() {
    log_event("BOOT", "Bootloader handed control");
    kernel_main();
}