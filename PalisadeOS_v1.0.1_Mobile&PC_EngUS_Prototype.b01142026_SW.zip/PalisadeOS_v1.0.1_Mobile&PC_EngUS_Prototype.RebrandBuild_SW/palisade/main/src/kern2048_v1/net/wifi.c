// kernel/net/wifi.c
#include "net.h"
#include "system.h"

void wifi_connect(const char *ssid) {
    if (!net_is_up()) {
        log_event("WIFI", "Network stack not ready");
        return;
    }

    log_event("WIFI", "Connected to WiFi network");
}