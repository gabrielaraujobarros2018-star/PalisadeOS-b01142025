// kernel/net/net_core.c (extended)
#include "net.h"
#include "power.h"
#include "system.h"

static int net_up = 0;

void net_init() {
    net_up = 1;
    power_wake_event("NET_INIT");
    log_event("NET", "Network stack initialized");
}