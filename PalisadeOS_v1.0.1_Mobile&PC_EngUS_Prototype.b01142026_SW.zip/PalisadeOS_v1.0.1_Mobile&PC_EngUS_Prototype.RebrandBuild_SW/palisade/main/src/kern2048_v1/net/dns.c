// kernel/net/dns.c
#include <string.h>
#include "net.h"
#include "system.h"

const char *dns_resolve(const char *host) {
    log_event("DNS", host);

    if (strcmp(host, "localhost") == 0)
        return "127.0.0.1";

    return "0.0.0.0";
}