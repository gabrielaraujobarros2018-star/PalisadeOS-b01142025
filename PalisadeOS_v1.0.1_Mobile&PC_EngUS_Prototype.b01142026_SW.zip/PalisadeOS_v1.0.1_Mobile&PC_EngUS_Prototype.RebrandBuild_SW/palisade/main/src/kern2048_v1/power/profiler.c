// kernel/power/profiler.c
#include "power.h"
#include "system.h"

static int wake_events = 0;

void power_wake_event(const char *source) {
    wake_events++;
    log_event("POWER_WAKE", source);
}

int power_wake_count() {
    return wake_events;
}