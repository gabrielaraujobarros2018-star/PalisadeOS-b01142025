// kernel/power/charge.c
#include "power.h"
#include "system.h"

static int charging = 0;

void charge_set(int state) {
    charging = state;

    if (state) {
        log_event("CHARGE", "Charging started");
        power_set_idle(1);
    } else {
        log_event("CHARGE", "Charging stopped");
    }
}

int charge_is_active() {
    return charging;
}