// kernel/power/thermal.c
#include <stdio.h>
#include "power.h"
#include "system.h"

static float last_temp = 30.0f;

void thermal_update(float new_temp) {
    last_temp = new_temp;

    if (new_temp > 45.0f) {
        log_event("THERMAL", "High temperature detected");
        power_set_idle(1);
    }
}

float thermal_get() {
    return last_temp;
}