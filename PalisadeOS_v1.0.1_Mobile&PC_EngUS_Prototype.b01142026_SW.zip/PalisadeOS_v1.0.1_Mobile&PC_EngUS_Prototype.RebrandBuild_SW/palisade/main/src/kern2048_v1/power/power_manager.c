// kernel/power/power_manager.c
#include "power.h"
#include "system.h"

static int system_idle = 1;

void power_set_idle(int state) {
    system_idle = state;
    log_event("POWER", state ? "System entered idle" : "System exited idle");
}

int power_is_idle() {
    return system_idle;
}