// system/main.c
#include "system.h"
#include "hw.h"
#include "net.h"
#include "power.h"

void kernel_main() {
    log_event("BOOT", "Kernel entry");

    device_init("generic-device");
    net_init();
    power_set_idle(1);

    log_event("BOOT", "System ready");
}