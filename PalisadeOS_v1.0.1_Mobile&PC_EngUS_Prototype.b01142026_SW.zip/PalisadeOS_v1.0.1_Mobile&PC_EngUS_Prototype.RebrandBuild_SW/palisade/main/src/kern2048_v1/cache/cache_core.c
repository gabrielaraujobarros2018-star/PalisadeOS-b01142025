// kernel/cache/cache_core.c
#include "cache.h"
#include "system.h"

static int cache_items = 0;

void cache_store() {
    cache_items++;
    log_event("CACHE", "Item stored");
}

int cache_count() {
    return cache_items;
}