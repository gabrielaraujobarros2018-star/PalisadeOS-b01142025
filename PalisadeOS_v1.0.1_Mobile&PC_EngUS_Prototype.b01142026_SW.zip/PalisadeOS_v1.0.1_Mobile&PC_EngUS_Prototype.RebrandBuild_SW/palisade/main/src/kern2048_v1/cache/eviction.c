// kernel/cache/eviction.c
#include "cache.h"
#include "system.h"

void cache_evict_all() {
    log_event("CACHE", "Cache evicted");
}