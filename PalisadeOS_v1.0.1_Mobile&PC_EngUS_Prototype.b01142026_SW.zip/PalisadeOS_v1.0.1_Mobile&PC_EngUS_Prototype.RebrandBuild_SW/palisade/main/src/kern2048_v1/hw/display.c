// kernel/hw/display.c
#include <stdio.h>
#include "hw.h"

void display_print(const char *msg) {
    printf("[DISPLAY] %s\n", msg);
}