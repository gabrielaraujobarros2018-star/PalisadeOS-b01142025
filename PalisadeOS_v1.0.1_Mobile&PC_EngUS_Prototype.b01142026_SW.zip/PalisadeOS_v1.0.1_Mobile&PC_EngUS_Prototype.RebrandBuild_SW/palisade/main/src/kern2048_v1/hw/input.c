// kernel/hw/input.c
#include "hw.h"
#include "system.h"

void input_event(const char *evt) {
    log_event("INPUT", evt);
}