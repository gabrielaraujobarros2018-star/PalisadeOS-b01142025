// kernel/hw/device.c
#include "hw.h"
#include "system.h"

void device_init(const char *name) {
    log_event("HW", name);
}