// kernel/hw/probe.c
#include "hw.h"
#include "system.h"

void hw_probe() {
    log_event("HW", "Probing hardware");
    device_init("display");
    device_init("touch");
    device_init("battery");
}