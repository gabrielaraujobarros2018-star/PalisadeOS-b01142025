// kernel/hw/platform.c
#include "system.h"

const char *platform_name() {
    return "PalisadeOS-generic-phone";
}